
import React, { useState, useEffect } from 'react';
import { motion as _motion, AnimatePresence } from 'framer-motion';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import TrustStrip from './components/TrustStrip';
import AboutSection from './components/AboutSection';
import AboutMeSection from './components/AboutMeSection';
import AboutPage from './components/AboutPage';
import ServicesSection from './components/ServicesSection';
import YouTubeSection from './components/YouTubeSection';
import ProjectsSection from './components/ProjectsSection';
import DealsSection from './components/DealsSection';
import ResourcesSection from './components/ResourcesSection';
import TestimonialsSection from './components/TestimonialsSection';
import BookingSection from './components/BookingSection';
import Footer from './components/Footer';
import AllServices from './components/AllServices';
import AllProjects from './components/AllProjects';
import AllDeals from './components/AllDeals';
import AllResources from './components/AllResources';
import FloatingActions from './components/FloatingActions';

// Fix: Cast motion to any to bypass environment-specific type resolution issues for motion props
const motion = _motion as any;

const App: React.FC = () => {
  const [view, setView] = useState<'home' | 'services' | 'projects' | 'deals' | 'resources' | 'about'>('home');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [view]);

  return (
    <main className="selection:bg-red-500/30 selection:text-white bg-black min-h-screen relative">
      <Navbar onNavigate={setView} currentView={view} />
      
      <AnimatePresence mode="wait">
        {view === 'home' && (
          <motion.div
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <Hero />
            <TrustStrip />
            <AboutSection />
            <AboutMeSection onViewMore={() => setView('about')} />
            <ServicesSection onViewMore={() => setView('services')} />
            <YouTubeSection />
            <ProjectsSection onViewMore={() => setView('projects')} />
            <DealsSection onViewMore={() => setView('deals')} />
            <ResourcesSection onViewMore={() => setView('resources')} />
            <TestimonialsSection />
            <BookingSection />
            <Footer />
          </motion.div>
        )}

        {view === 'about' && (
          <motion.div
            key="about"
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
          >
            <AboutPage onBack={() => setView('home')} />
            <Footer />
          </motion.div>
        )}

        {view === 'services' && (
          <motion.div
            key="all-services"
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
          >
            <AllServices onBack={() => setView('home')} />
            <Footer />
          </motion.div>
        )}

        {view === 'projects' && (
          <motion.div
            key="all-projects"
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
          >
            <AllProjects onBack={() => setView('home')} />
            <Footer />
          </motion.div>
        )}

        {view === 'deals' && (
          <motion.div
            key="all-deals"
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
          >
            <AllDeals onBack={() => setView('home')} />
            <Footer />
          </motion.div>
        )}

        {view === 'resources' && (
          <motion.div
            key="all-resources"
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
          >
            <AllResources onBack={() => setView('home')} />
            <Footer />
          </motion.div>
        )}
      </AnimatePresence>

      <FloatingActions />
    </main>
  );
};

export default App;
