
import React from 'react';
import { motion as _motion } from 'framer-motion';
import { SERVICES, ICON_MAP } from '../constants';
import { CheckCircle2, ChevronLeft } from 'lucide-react';

// Fix: Cast motion to any to bypass environment-specific type resolution issues for motion props
const motion = _motion as any;

const AllServices: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  return (
    <div className="pt-32 pb-24 bg-black">
      <div className="container mx-auto px-6">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-neutral-400 hover:text-white transition-colors mb-8 font-bold"
        >
          <ChevronLeft /> Back to Home
        </button>
        
        <div className="mb-16">
          <h1 className="text-5xl md:text-7xl font-brand font-black text-gradient-red mb-6">Expert Services</h1>
          <p className="text-xl text-neutral-400 max-w-3xl">
            Complete high-performance solutions designed for business growth, automation, and superior customer experience.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {SERVICES.map((service, index) => {
            const Icon = ICON_MAP[service.icon];
            return (
              <motion.div 
                key={service.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-neutral-900 p-8 rounded-[2.5rem] border border-white/5 group"
              >
                <div className="w-16 h-16 rounded-2xl bg-red-500/10 flex items-center justify-center text-red-500 mb-8 group-hover:scale-110 transition-transform">
                  <Icon size={32} />
                </div>
                <h3 className="text-3xl font-brand font-bold mb-4 text-white">{service.title}</h3>
                <p className="text-neutral-400 text-lg mb-8 leading-relaxed">{service.description}</p>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {service.features.map((feat, i) => (
                    <li key={i} className="flex items-center gap-3 text-neutral-300 font-medium">
                      <CheckCircle2 className="text-red-500" size={20} />
                      {feat}
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default AllServices;
