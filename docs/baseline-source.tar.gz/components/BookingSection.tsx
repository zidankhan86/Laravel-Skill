
import React from 'react';
import { Calendar, Clock, Globe2, Phone, Mail, MessageCircle } from 'lucide-react';
import { BRAND_INFO } from '../constants';

const BookingSection: React.FC = () => {
  return (
    <section id="booking" className="py-24 bg-black relative">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-red-500/50 to-transparent"></div>
      
      <div className="container mx-auto px-6">
        <div className="bg-neutral-900 rounded-[3rem] p-8 lg:p-16 border border-white/5 relative overflow-hidden">
          <div className="flex flex-col lg:flex-row gap-16">
            
            <div className="w-full lg:w-1/2 space-y-8">
              <h2 className="text-4xl md:text-5xl font-brand font-black leading-tight text-white">Let's Build Your <br/> <span className="text-gradient-red">Sales Ecosystem</span></h2>
              
              <div className="space-y-6">
                <div className="flex items-start gap-5">
                  <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center text-red-500 shrink-0">
                    <Clock />
                  </div>
                  <div className="text-white">
                    <h4 className="font-bold text-xl mb-1">Free 30-min Strategy Call</h4>
                    <p className="text-neutral-400">Deep dive into your current business bottlenecks and roadmap to scale.</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-5">
                  <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center text-red-500 shrink-0">
                    <Globe2 />
                  </div>
                  <div className="text-white">
                    <h4 className="font-bold text-xl mb-1">Global & Local Delivery</h4>
                    <p className="text-neutral-400">Available for brands in Bangladesh and internationally.</p>
                  </div>
                </div>
              </div>

              <div id="contact" className="pt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
                 <a href={`mailto:${BRAND_INFO.email}`} className="flex items-center gap-3 p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-red-500/30 transition-all text-white">
                    <Mail className="text-red-500" /> <span>Email Me</span>
                 </a>
                 <a href={`tel:+88${BRAND_INFO.phone}`} className="flex items-center gap-3 p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-red-500/30 transition-all text-white">
                    <Phone className="text-red-500" /> <span>Call Direct</span>
                 </a>
                 <a href={`https://wa.me/${BRAND_INFO.whatsapp}`} target="_blank" className="flex items-center gap-3 p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-red-500/30 transition-all text-white">
                    <MessageCircle className="text-green-500" /> <span>WhatsApp</span>
                 </a>
              </div>
            </div>

            <div className="w-full lg:w-1/2">
              <div className="bg-black/50 p-1 rounded-3xl border border-white/10 aspect-square lg:aspect-auto min-h-[500px] flex items-center justify-center relative group">
                <div className="text-center space-y-4">
                   <Calendar size={64} className="mx-auto text-neutral-700 group-hover:text-red-500 transition-colors" />
                   <p className="text-neutral-500 font-medium">Calendar Integration Placeholder</p>
                   <button className="bg-gradient-red px-10 py-4 rounded-xl text-white font-bold soft-shadow hover-lift">
                      Book Meeting Now
                   </button>
                </div>
                {/* Visual Flair */}
                <div className="absolute -top-10 -right-10 w-40 h-40 bg-red-500/5 blur-3xl -z-10"></div>
              </div>
            </div>

          </div>
        </div>

        <div className="mt-20 text-center max-w-3xl mx-auto px-6 py-12 rounded-3xl bg-gradient-to-r from-red-900/10 via-red-900/20 to-red-900/10 border border-red-500/10">
           <p className="text-2xl md:text-3xl font-brand font-bold mb-8 italic text-white">
              আপনি যদি শুধু ওয়েবসাইট না, একটা সিস্টেম, কন্ট্রোল আর ফিউচার চান— তাহলে এখনই কথা বলি।
           </p>
           <button onClick={() => window.open(`https://wa.me/${BRAND_INFO.whatsapp}`, '_blank')} className="bg-gradient-red px-12 py-5 rounded-2xl text-white font-black text-xl hover-lift soft-shadow uppercase tracking-widest">
              Start Your Journey
           </button>
        </div>
      </div>
    </section>
  );
};

export default BookingSection;
