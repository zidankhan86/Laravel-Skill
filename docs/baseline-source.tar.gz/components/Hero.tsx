
import React from 'react';
import { motion as _motion } from 'framer-motion';
import { Phone, Calendar, Mail, Globe } from 'lucide-react';
import { BRAND_INFO } from '../constants';

// Fix: Cast motion to any to bypass environment-specific type resolution issues for motion props
const motion = _motion as any;

const Hero: React.FC = () => {
  const scrollTo = (id: string) => {
    const el = document.querySelector(id);
    if (el) {
       const offset = 80;
       const elementPosition = el.getBoundingClientRect().top + window.pageYOffset;
       window.scrollTo({
         top: elementPosition - offset,
         behavior: 'smooth'
       });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Orbs */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-red-900/20 rounded-full blur-[120px] -z-10 animate-pulse"></div>
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-orange-900/10 rounded-full blur-[120px] -z-10 animate-pulse delay-700"></div>

      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-24">
          
          {/* Portrait Left */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="w-full lg:w-5/12 order-2 lg:order-1 relative group"
          >
            <div className="absolute inset-0 bg-gradient-red rounded-[2rem] blur-2xl opacity-20 group-hover:opacity-40 transition-opacity"></div>
            <div className="relative z-10 rounded-[2rem] border-2 border-white/10 overflow-hidden bg-neutral-900 aspect-[4/5] soft-shadow">
               <img 
                 src="./assets/tanvir.png" 
                 onError={(e) => {
                   (e.target as HTMLImageElement).src = "https://raw.githubusercontent.com/tanvir8332/Portfolio-Images/main/Tanvir-Portrait-Clean.png";
                 }}
                 alt={BRAND_INFO.name} 
                 className="w-full h-full object-cover grayscale-[0.2] hover:grayscale-0 transition-all duration-700 scale-105 hover:scale-100"
               />
            </div>
            
            <motion.div 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.5, type: 'spring' }}
              className="absolute -bottom-6 -right-6 bg-black/80 backdrop-blur-md p-4 rounded-2xl border border-white/10 soft-shadow z-20 hidden sm:block"
            >
               <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center text-green-500">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                  </div>
                  <div>
                    <p className="text-xs text-neutral-400 uppercase font-bold tracking-widest">Experience</p>
                    <p className="text-lg font-bold text-white">5+ Years</p>
                  </div>
               </div>
            </motion.div>
          </motion.div>

          {/* Content Right */}
          <div className="w-full lg:w-7/12 order-1 lg:order-2 space-y-8 text-center lg:text-left">
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex flex-col sm:flex-row items-center gap-3 px-4 py-2 rounded-2xl bg-white/5 border border-white/10 text-sm font-semibold mb-2"
            >
              <div className="flex items-center gap-2 text-red-400">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                </span>
                Available for New Projects
              </div>
              <div className="hidden sm:block w-1 h-1 bg-neutral-600 rounded-full"></div>
              <a href={BRAND_INFO.founderUrl} target="_blank" className="text-neutral-400 hover:text-white transition-colors flex items-center gap-1.5">
                <Globe size={14} className="text-red-500" /> Founder, {BRAND_INFO.founderOf}
              </a>
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-5xl md:text-7xl font-brand font-black leading-tight"
            >
              <span className="text-gradient-red">{BRAND_INFO.name}</span>
            </motion.h1>
            
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-2xl md:text-3xl font-bold text-neutral-300"
            >
              eCommerce Website Architect & <br className="hidden md:block"/> Automation Specialist
            </motion.h2>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-lg md:text-xl text-neutral-400 max-w-2xl leading-relaxed mx-auto lg:mx-0"
            >
              আমি শুধু ওয়েবসাইট বানাই না। আমি কাস্টমারের সাইকোলজি, অটোমেশন এবং সিস্টেম ব্যবহার করে একটি ওয়েবসাইটকে <span className="text-white font-semibold">Ultimate Sales Machine</span> এ রূপান্তর করি।
            </motion.p>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="flex flex-wrap justify-center lg:justify-start gap-4"
            >
              <button onClick={() => scrollTo('#booking')} className="flex items-center gap-2 bg-gradient-red px-8 py-4 rounded-xl text-white font-bold text-lg hover:scale-105 transition-all soft-shadow">
                <Calendar className="w-5 h-5" /> Book a Strategy Call
              </button>
              <button onClick={() => scrollTo('#contact')} className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-8 py-4 rounded-xl text-white font-bold text-lg hover:scale-105 transition-all border border-white/10">
                <Mail className="w-5 h-5" /> Contact Me
              </button>
              <a href={`tel:+88${BRAND_INFO.phone}`} className="flex items-center gap-3 bg-neutral-900 px-6 py-4 rounded-xl text-white font-bold text-lg hover:scale-105 transition-all border border-white/5">
                <Phone className="w-5 h-5 text-red-500" /> {BRAND_INFO.phone}
              </a>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
              className="pt-4 italic text-neutral-500 font-medium"
            >
              ❝ I don’t sell websites. I design how customers think, trust and buy. ❞
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Hero;
