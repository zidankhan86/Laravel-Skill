
import React from 'react';
import { Target, Eye, Brain } from 'lucide-react';

const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-black relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center mb-20">
          <h2 className="text-gradient-red text-4xl md:text-5xl font-brand font-black mb-8">Who I Am & Why I Exist</h2>
          <p className="text-xl text-neutral-300 leading-relaxed mb-6 font-medium">
            আমি বিশ্বাস করি— আজকের দিনে ব্যবসা ব্যর্থ হয় প্রোডাক্টের জন্য না, ব্যর্থ হয় সঠিক সিস্টেম না থাকার জন্য।
          </p>
          <div className="flex flex-col md:flex-row items-center justify-center gap-4 text-lg">
             <span className="px-6 py-2 bg-red-500/10 text-red-400 border border-red-500/20 rounded-full font-bold">❌ Chaos থেকে</span>
             <span className="text-neutral-500 text-2xl">➔</span>
             <span className="px-6 py-2 bg-green-500/10 text-green-400 border border-green-500/20 rounded-full font-bold">✅ Control এ আনা</span>
          </div>
          <p className="mt-8 text-neutral-400 text-lg">
            আমার মিশন হলো— বাংলাদেশের উদ্যোক্তাদের জন্য ওয়েবসাইট, অটোমেশন, কাস্টমার সাইকোলজি এবং ডেটা ব্যবহার করে একটি Sustainable, Scalable Online Business Ecosystem তৈরি করা।
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Mission */}
          <div className="bg-neutral-900 p-8 rounded-[2.5rem] border border-white/5 hover:border-red-500/30 transition-all hover-lift group">
            <div className="w-16 h-16 bg-red-500/10 rounded-2xl flex items-center justify-center text-red-500 mb-6 group-hover:scale-110 transition-transform">
              <Target size={32} />
            </div>
            <h3 className="text-2xl font-brand font-bold mb-4">Our Mission</h3>
            <p className="text-neutral-400 leading-relaxed">
              বাংলাদেশের উদ্যোক্তাদের জন্য System-driven, automation-ready eCommerce business তৈরি করা।
            </p>
          </div>

          {/* Vision */}
          <div className="bg-neutral-900 p-8 rounded-[2.5rem] border border-white/5 hover:border-red-500/30 transition-all hover-lift group">
            <div className="w-16 h-16 bg-red-500/10 rounded-2xl flex items-center justify-center text-red-500 mb-6 group-hover:scale-110 transition-transform">
              <Eye size={32} />
            </div>
            <h3 className="text-2xl font-brand font-bold mb-4">Our Vision</h3>
            <p className="text-neutral-400 leading-relaxed">
              বাংলাদেশে এমন একটি স্ট্যান্ডার্ড তৈরি করা যেখানে ওয়েবসাইট মানেই হবে <br/>👉 Trust 👉 Automation 👉 Sales Machine.
            </p>
          </div>

          {/* Belief */}
          <div className="bg-neutral-900 p-8 rounded-[2.5rem] border border-white/5 hover:border-red-500/30 transition-all hover-lift group">
            <div className="w-16 h-16 bg-red-500/10 rounded-2xl flex items-center justify-center text-red-500 mb-6 group-hover:scale-110 transition-transform">
              <Brain size={32} />
            </div>
            <h3 className="text-2xl font-brand font-bold mb-4">Our Belief</h3>
            <p className="text-neutral-400 leading-relaxed italic">
              “A website should think like a customer, not look like a poster.”
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
