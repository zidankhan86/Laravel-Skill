
import React from 'react';
import { Facebook, Linkedin, Twitter, Youtube, Instagram, Github, Globe } from 'lucide-react';
import { BRAND_INFO } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black pt-20 pb-10 border-t border-white/5">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-start gap-12 mb-20">
          <div className="space-y-6 max-w-sm">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-red rounded-lg flex items-center justify-center font-brand font-black text-xl">T</div>
              <span className="font-brand font-bold text-2xl tracking-tight text-white">TANVIR<span className="text-red-500">.</span></span>
            </div>
            <p className="text-neutral-500 leading-relaxed font-medium">
              Building automated sales systems that empower entrepreneurs to gain control and scale effortlessly.
            </p>
            <div className="pt-2">
              <a href={BRAND_INFO.founderUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-red-500 font-bold hover:underline">
                <Globe size={18} /> Founder, {BRAND_INFO.founderOf}
              </a>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <a href={BRAND_INFO.socials.facebook} target="_blank" className="p-2.5 bg-neutral-900 rounded-xl hover:text-red-500 transition-colors text-white"><Facebook size={20} /></a>
              <a href={BRAND_INFO.socials.linkedin} target="_blank" className="p-2.5 bg-neutral-900 rounded-xl hover:text-red-500 transition-colors text-white"><Linkedin size={20} /></a>
              <a href={BRAND_INFO.socials.twitter} target="_blank" className="p-2.5 bg-neutral-900 rounded-xl hover:text-red-500 transition-colors text-white"><Twitter size={20} /></a>
              <a href={BRAND_INFO.socials.youtube} target="_blank" className="p-2.5 bg-neutral-900 rounded-xl hover:text-red-500 transition-colors text-white"><Youtube size={20} /></a>
              <a href={BRAND_INFO.socials.instagram} target="_blank" className="p-2.5 bg-neutral-900 rounded-xl hover:text-red-500 transition-colors text-white"><Instagram size={20} /></a>
              <a href={BRAND_INFO.socials.github} target="_blank" className="p-2.5 bg-neutral-900 rounded-xl hover:text-red-500 transition-colors text-white"><Github size={20} /></a>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-12">
            <div className="space-y-4">
              <h4 className="font-brand font-bold text-white uppercase text-xs tracking-[0.2em]">Sitemap</h4>
              <ul className="space-y-2 text-neutral-500 text-sm font-semibold">
                <li><a href="#about" className="hover:text-red-500">About</a></li>
                <li><a href="#services" className="hover:text-red-500">Services</a></li>
                <li><a href="#youtube" className="hover:text-red-500">YouTube</a></li>
                <li><a href="#projects" className="hover:text-red-500">Projects</a></li>
              </ul>
            </div>
            <div className="space-y-4">
              <h4 className="font-brand font-bold text-white uppercase text-xs tracking-[0.2em]">Contact</h4>
              <ul className="space-y-2 text-neutral-500 text-sm font-semibold">
                <li className="break-all">{BRAND_INFO.email}</li>
                <li>+88{BRAND_INFO.phone}</li>
                <li>Dhaka, Bangladesh</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-neutral-500 text-sm font-medium">
          <p>© {new Date().getFullYear()} {BRAND_INFO.name}. All rights reserved.</p>
          <p>Building systems, not just websites.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
