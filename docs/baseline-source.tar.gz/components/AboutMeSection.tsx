
import React from 'react';
import { motion as _motion } from 'framer-motion';
import { BRAND_INFO } from '../constants';
import { ArrowRight, UserCheck } from 'lucide-react';

const motion = _motion as any;

interface AboutMeSectionProps {
  onViewMore: () => void;
}

const AboutMeSection: React.FC<AboutMeSectionProps> = ({ onViewMore }) => {
  return (
    <section id="aboutme" className="pb-24 bg-black relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          
          {/* Left Side: Content */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="w-full lg:w-1/2 space-y-8"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-red-500/10 border border-red-500/20 text-red-500 font-bold text-xs uppercase tracking-widest">
              <UserCheck size={14} /> My Journey
            </div>
            <h2 className="text-4xl md:text-5xl font-brand font-black text-white leading-tight">
              I Help Founders Transition From <br/>
              <span className="text-gradient-red">Chaos To Absolute Control</span>
            </h2>
            <p className="text-xl text-neutral-400 leading-relaxed italic">
              "{BRAND_INFO.aboutBio}"
            </p>
            <div className="pt-4">
              <button 
                onClick={onViewMore}
                className="group inline-flex items-center gap-3 bg-white/5 border border-white/10 px-8 py-4 rounded-2xl text-white font-bold hover:bg-white/10 transition-all"
              >
                Read Full Story <ArrowRight className="group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </motion.div>

          {/* Right Side: Image with Gradient Border */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="w-full lg:w-1/2 relative"
          >
            <div className="relative z-10 p-3 bg-gradient-red rounded-[3rem] shadow-2xl overflow-hidden aspect-square max-w-lg mx-auto">
              <div className="w-full h-full bg-neutral-900 rounded-[2.5rem] overflow-hidden">
                <img 
                  src="./assets/tanvir.png" 
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = "https://raw.githubusercontent.com/tanvir8332/Portfolio-Images/main/Tanvir-Portrait-Clean.png";
                  }}
                  alt={BRAND_INFO.name} 
                  className="w-full h-full object-cover grayscale-[0.5] hover:grayscale-0 transition-all duration-700"
                />
              </div>
            </div>
            {/* Background Glow Elements */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-red-500/10 blur-3xl -z-10 animate-pulse"></div>
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-red-900/10 blur-3xl -z-10 animate-pulse delay-700"></div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default AboutMeSection;
