
import React from 'react';
import { motion as _motion } from 'framer-motion';
import { SERVICES, ICON_MAP } from '../constants';
import { CheckCircle2, ArrowRight } from 'lucide-react';

// Fix: Cast motion to any to bypass environment-specific type resolution issues for motion props
const motion = _motion as any;

interface ServicesSectionProps {
  onViewMore: () => void;
}

const ServicesSection: React.FC<ServicesSectionProps> = ({ onViewMore }) => {
  return (
    <section id="services" className="py-24 bg-neutral-950 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-brand font-black mb-4">Premium Solutions</h2>
          <p className="text-neutral-500 max-w-2xl mx-auto text-lg">
            Focused on ROI, psychology, and long-term business sustainability.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8 mb-16">
          {SERVICES.slice(0, 3).map((service, index) => {
            const Icon = ICON_MAP[service.icon];
            return (
              <motion.div 
                key={service.id} 
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="relative group rounded-[2rem] p-[2px] bg-gradient-to-br from-white/10 to-transparent hover:from-red-500/50 hover:to-orange-500/50 transition-all duration-500"
              >
                <div className="h-full bg-neutral-900 rounded-[2rem] p-8 md:p-10 flex flex-col justify-between">
                  <div>
                    <div className="w-14 h-14 rounded-xl bg-gradient-red flex items-center justify-center mb-8 soft-shadow group-hover:scale-110 transition-transform">
                      <Icon className="text-white" size={28} />
                    </div>
                    <h3 className="text-2xl font-brand font-bold mb-4 group-hover:text-red-400 transition-colors">{service.title}</h3>
                    <p className="text-neutral-400 mb-8">{service.description}</p>
                    
                    <ul className="space-y-3 mb-10">
                      {service.features.map((feat, i) => (
                        <li key={i} className="flex items-center gap-2 text-sm font-semibold text-neutral-300">
                          <CheckCircle2 className="text-red-500" size={16} />
                          {feat}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <a href="#booking" className="flex-1 text-center py-3 rounded-xl bg-white/5 border border-white/10 font-bold hover:bg-gradient-red hover:border-transparent transition-all text-white">
                      Book Now
                    </a>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="text-center"
        >
          <button 
            onClick={onViewMore}
            className="group inline-flex items-center gap-2 px-8 py-4 bg-white/5 border border-white/10 rounded-full font-bold text-white hover:bg-white/10 transition-all"
          >
            View All Services <ArrowRight className="group-hover:translate-x-1 transition-transform" />
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default ServicesSection;
