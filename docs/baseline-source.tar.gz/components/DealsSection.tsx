
import React from 'react';
import { motion as _motion } from 'framer-motion';
import { DEALS } from '../constants';
import { Tag as TagIcon, ExternalLink, ArrowRight } from 'lucide-react';

// Fix: Cast motion to any to bypass environment-specific type resolution issues for motion props
const motion = _motion as any;

interface DealsSectionProps {
  onViewMore: () => void;
}

const DealsSection: React.FC<DealsSectionProps> = ({ onViewMore }) => {
  return (
    <section id="deals" className="py-24 bg-neutral-900/30">
      <div className="container mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-brand font-black mb-4">Recommended Tools & Deals</h2>
          <p className="text-neutral-500 max-w-2xl mx-auto text-lg">
            Exclusive discounts on high-performance hosting, themes, and business automation tools I personally trust.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {DEALS.slice(0, 3).map((deal, index) => (
            <motion.div 
              key={deal.id} 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative bg-neutral-900 border border-white/5 rounded-[2.5rem] overflow-hidden"
            >
              <div className="aspect-[16/9] overflow-hidden relative">
                <img 
                  src={deal.image} 
                  alt={deal.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-gradient-red px-4 py-2 rounded-full text-white text-xs font-black uppercase tracking-widest soft-shadow">
                    {deal.discount}
                  </span>
                </div>
              </div>
              
              <div className="p-8">
                <div className="flex items-center gap-2 mb-3">
                  <TagIcon size={14} className="text-red-500" />
                  <span className="text-xs font-bold text-neutral-500 uppercase tracking-widest">{deal.tag}</span>
                </div>
                <h3 className="text-2xl font-brand font-bold mb-3 text-white group-hover:text-red-400 transition-colors">
                  {deal.title}
                </h3>
                <p className="text-neutral-400 mb-6 line-clamp-2">
                  {deal.description}
                </p>
                <a 
                  href={deal.link} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-white font-bold group/btn"
                >
                  Claim Deal <ExternalLink size={18} className="text-red-500 group-hover/btn:translate-x-1 transition-transform" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="text-center"
        >
          <button 
            onClick={onViewMore}
            className="group inline-flex items-center gap-2 px-8 py-4 bg-white/5 border border-white/10 rounded-full font-bold text-white hover:bg-white/10 transition-all"
          >
            View All Deals <ArrowRight className="group-hover:translate-x-1 transition-transform" />
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default DealsSection;
