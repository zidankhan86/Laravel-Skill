
import React from 'react';
import { motion as _motion } from 'framer-motion';
import { RESOURCES, BRAND_INFO } from '../constants';
import { BookOpen, Download, MessageCircle, ArrowRight, FileText } from 'lucide-react';

const motion = _motion as any;

interface ResourcesSectionProps {
  onViewMore: () => void;
}

const ResourcesSection: React.FC<ResourcesSectionProps> = ({ onViewMore }) => {
  const handlePaidRequest = (title: string) => {
    const message = encodeURIComponent(`I am interested in getting the "${title}". Please share the details.`);
    window.open(`https://wa.me/${BRAND_INFO.whatsapp}?text=${message}`, '_blank');
  };

  return (
    <section id="resources" className="py-24 bg-black relative overflow-hidden">
      <div className="container mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-brand font-black mb-4">Ebooks & Resources</h2>
          <p className="text-neutral-500 max-w-2xl mx-auto text-lg">
            Level up your business with my curated guides, documents, and automation blueprints.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {RESOURCES.slice(0, 4).map((resource, index) => (
            <motion.div 
              key={resource.id} 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group bg-neutral-900/50 border border-white/5 rounded-3xl overflow-hidden hover:border-red-500/30 transition-all"
            >
              <div className="aspect-[3/4] overflow-hidden relative">
                <img 
                  src={resource.image} 
                  alt={resource.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                />
                <div className="absolute top-4 right-4">
                  <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest soft-shadow ${
                    resource.type === 'free' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
                  }`}>
                    {resource.type}
                  </span>
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex items-center gap-2 mb-2 text-neutral-500">
                  <FileText size={14} className="text-red-500" />
                  <span className="text-[10px] font-bold uppercase tracking-widest">{resource.tag}</span>
                </div>
                <h3 className="text-lg font-brand font-bold mb-3 text-white line-clamp-1">
                  {resource.title}
                </h3>
                
                {resource.type === 'free' ? (
                  <a 
                    href={resource.downloadUrl} 
                    className="flex items-center justify-center gap-2 w-full py-3 bg-white/5 border border-white/10 rounded-xl text-white font-bold hover:bg-gradient-red hover:border-transparent transition-all text-sm"
                  >
                    <Download size={16} /> Download Free
                  </a>
                ) : (
                  <button 
                    onClick={() => handlePaidRequest(resource.title)}
                    className="flex items-center justify-center gap-2 w-full py-3 bg-white/5 border border-white/10 rounded-xl text-white font-bold hover:bg-green-600 hover:border-transparent transition-all text-sm"
                  >
                    <MessageCircle size={16} /> Get on WhatsApp
                  </button>
                )}
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="text-center"
        >
          <button 
            onClick={onViewMore}
            className="group inline-flex items-center gap-2 px-8 py-4 bg-white/5 border border-white/10 rounded-full font-bold text-white hover:bg-white/10 transition-all"
          >
            Explore All Resources <ArrowRight className="group-hover:translate-x-1 transition-transform" />
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default ResourcesSection;
