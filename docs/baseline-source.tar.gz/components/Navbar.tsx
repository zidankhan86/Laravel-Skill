
import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { motion as _motion, AnimatePresence } from 'framer-motion';

// Fix: Cast motion to any to bypass environment-specific type resolution issues for motion props
const motion = _motion as any;

interface NavbarProps {
  onNavigate: (view: 'home' | 'services' | 'projects' | 'deals' | 'resources' | 'about') => void;
  currentView: 'home' | 'services' | 'projects' | 'deals' | 'resources' | 'about';
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate, currentView }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About', href: '#aboutme' },
    { name: 'Services', href: '#services' },
    { name: 'Projects', href: '#projects' },
    { name: 'Deals', href: '#deals' },
    { name: 'Resources', href: '#resources' },
    { name: 'Reviews', href: '#testimonials' },
  ];

  const handleLinkClick = (href: string) => {
    setIsMobileMenuOpen(false);
    if (currentView !== 'home') {
      onNavigate('home');
      setTimeout(() => {
        scrollToSection(href);
      }, 300);
    } else {
      scrollToSection(href);
    }
  };

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled || currentView !== 'home' ? 'bg-black/90 backdrop-blur-md py-4 shadow-xl border-b border-white/10' : 'bg-transparent py-6'}`}>
        <div className="container mx-auto px-6 flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2 cursor-pointer" 
            onClick={() => onNavigate('home')}
          >
            <div className="w-10 h-10 bg-gradient-red rounded-lg flex items-center justify-center font-brand font-black text-xl text-white">T</div>
            <span className="font-brand font-bold text-xl tracking-tight hidden sm:block text-white">TANVIR<span className="text-red-500">.</span></span>
          </motion.div>
          
          <div className="hidden lg:flex items-center gap-8 text-sm font-medium tracking-wide">
            {navLinks.map((link) => (
              <button 
                key={link.name} 
                onClick={() => handleLinkClick(link.href)}
                className="hover:text-red-500 transition-colors text-neutral-300 font-bold uppercase tracking-widest text-[10px]"
              >
                {link.name}
              </button>
            ))}
            <button 
              onClick={() => handleLinkClick('#booking')}
              className="bg-gradient-red px-6 py-2.5 rounded-full text-white font-bold hover:scale-105 transition-transform soft-shadow text-xs uppercase"
            >
              Book Call
            </button>
          </div>
          
          <motion.button 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:hidden text-white p-2"
            onClick={() => setIsMobileMenuOpen(true)}
          >
            <Menu size={28} />
          </motion.button>
        </div>
      </nav>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] lg:hidden"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 bottom-0 w-[80%] max-w-sm bg-neutral-950 z-[70] p-10 border-l border-white/10 flex flex-col lg:hidden"
            >
              <div className="flex justify-between items-center mb-12">
                <span className="font-brand font-bold text-2xl tracking-tight text-white">TANVIR<span className="text-red-500">.</span></span>
                <button onClick={() => setIsMobileMenuOpen(false)} className="p-2 bg-white/5 rounded-lg text-white">
                  <X size={24} />
                </button>
              </div>

              <div className="flex flex-col gap-6 text-xl font-bold">
                {navLinks.map((link, idx) => (
                  <motion.button
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 * idx }}
                    key={link.name}
                    onClick={() => handleLinkClick(link.href)}
                    className="text-left hover:text-red-500 transition-colors text-white uppercase tracking-widest text-sm"
                  >
                    {link.name}
                  </motion.button>
                ))}
                <motion.button
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 }}
                  onClick={() => handleLinkClick('#booking')}
                  className="mt-4 bg-gradient-red text-white py-4 rounded-2xl soft-shadow text-sm uppercase tracking-widest"
                >
                  Book Call Now
                </motion.button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default Navbar;
