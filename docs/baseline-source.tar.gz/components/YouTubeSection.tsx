
import React from 'react';
import { VIDEOS, BRAND_INFO } from '../constants';
import { PlayCircle, Youtube } from 'lucide-react';

const YouTubeSection: React.FC = () => {
  return (
    <section id="youtube" className="py-24 bg-black">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-end justify-between mb-16 gap-8">
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-brand font-black mb-6 text-white">Learn How Modern eCommerce Really Works</h2>
            <p className="text-neutral-400 text-lg leading-relaxed">
              আমি নিয়মিত ভিডিও শেয়ার করি যেখানে আলোচনা করি কেন ৯০% eCommerce fail করে, কাস্টমার কেন কিনে এবং Automation কিভাবে আপনার Profit এবং সময় বাঁচায়।
            </p>
          </div>
          <a href={BRAND_INFO.socials.youtube} target="_blank" className="flex items-center gap-3 bg-[#FF0000] px-8 py-4 rounded-xl text-white font-bold hover:scale-105 transition-all soft-shadow">
            <Youtube /> Subscribe on YouTube
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          {VIDEOS.map((video) => (
            <div key={video.id} className="group cursor-pointer">
              <div className="relative aspect-video rounded-2xl overflow-hidden mb-4 border border-white/5">
                <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-all flex items-center justify-center">
                  <PlayCircle className="text-white opacity-80 group-hover:opacity-100 transition-opacity scale-150" size={32} />
                </div>
                <div className="absolute bottom-3 right-3 bg-black/80 px-2 py-1 rounded text-xs font-bold text-white">
                  {video.duration}
                </div>
              </div>
              <h3 className="font-bold text-lg text-white group-hover:text-red-500 transition-colors line-clamp-2">{video.title}</h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default YouTubeSection;
