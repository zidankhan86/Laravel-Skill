
import React from 'react';
import { motion as _motion } from 'framer-motion';
import { PROJECTS } from '../constants';
import { ChevronLeft, ArrowUpRight } from 'lucide-react';

// Fix: Cast motion to any to bypass environment-specific type resolution issues for motion props
const motion = _motion as any;

const AllProjects: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  return (
    <div className="pt-32 pb-24 bg-black">
      <div className="container mx-auto px-6">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-neutral-400 hover:text-white transition-colors mb-8 font-bold"
        >
          <ChevronLeft /> Back to Home
        </button>
        
        <div className="mb-16">
          <h1 className="text-5xl md:text-7xl font-brand font-black text-gradient-red mb-6">Portfolio</h1>
          <p className="text-xl text-neutral-400 max-w-3xl">
            A selection of ecosystems I have architected to drive millions in revenue and automate complex operations.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {PROJECTS.map((project, index) => (
            <motion.div 
              key={project.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group space-y-6"
            >
              <div className="relative aspect-video rounded-[2.5rem] overflow-hidden border border-white/10">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-10">
                   <button className="bg-white text-black px-8 py-3 rounded-full font-bold flex items-center gap-2">
                     Live Preview <ArrowUpRight size={18} />
                   </button>
                </div>
              </div>
              <div>
                <span className="text-red-500 font-black uppercase text-xs tracking-widest">{project.category}</span>
                <h3 className="text-3xl font-brand font-bold text-white mt-2 group-hover:text-red-400 transition-colors">{project.title}</h3>
                <p className="text-neutral-400 text-lg mt-3">{project.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AllProjects;
