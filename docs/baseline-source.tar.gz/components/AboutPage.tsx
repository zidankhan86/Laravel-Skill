
import React from 'react';
import { motion as _motion } from 'framer-motion';
import { ChevronLeft, Award, Target, Brain, Quote } from 'lucide-react';
import { BRAND_INFO } from '../constants';

const motion = _motion as any;

const AboutPage: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  return (
    <div className="pt-32 pb-24 bg-black min-h-screen">
      <div className="container mx-auto px-6">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-neutral-400 hover:text-white transition-colors mb-12 font-bold"
        >
          <ChevronLeft /> Back to Home
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-start">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
          >
            <h1 className="text-5xl md:text-7xl font-brand font-black text-gradient-red">The Story Behind <br/> The Systems.</h1>
            <div className="prose prose-invert prose-lg text-neutral-400 leading-relaxed space-y-6">
              <p className="text-xl text-white font-medium">
                আমি বিশ্বাস করি— আজকের দিনে ব্যবসা ব্যর্থ হয় প্রোডাক্টের জন্য না, ব্যর্থ হয় সঠিক সিস্টেম না থাকার জন্য।
              </p>
              <p>
                {BRAND_INFO.aboutBio}
              </p>
              <p>
                আমার এই দীর্ঘ যাত্রায় আমি দেখেছি অসংখ্য উদ্যোক্তা তাদের ব্যবসার "Chaos" এর মধ্যে হারিয়ে যায়। তারা ২৪ ঘণ্টা কাজ করে কিন্তু তবুও ব্যবসা তাদের নিয়ন্ত্রণে থাকে না। আমি যখন কোনো বিজনেস ইকোসিস্টেম ডিজাইন করি, তখন আমার ফোকাস থাকে তিনটি জিনিসের ওপর: **ট্রাস্ট**, **অটোমেশন** এবং **স্কেলেবিলিটি**।
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-10">
                <div className="p-6 bg-neutral-900 rounded-3xl border border-white/5">
                  <Award className="text-red-500 mb-4" size={32} />
                  <h4 className="text-white font-bold mb-2">5+ Years</h4>
                  <p className="text-sm">Of deep industry experience in high-growth eCommerce.</p>
                </div>
                <div className="p-6 bg-neutral-900 rounded-3xl border border-white/5">
                  <Target className="text-red-500 mb-4" size={32} />
                  <h4 className="text-white font-bold mb-2">ROI Focused</h4>
                  <p className="text-sm">Every line of code and every funnel is built for profit.</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative"
          >
             <div className="sticky top-32 space-y-12">
                <div className="p-4 bg-gradient-red rounded-[3rem] shadow-2xl">
                   <img 
                     src="./assets/tanvir.png" 
                     onError={(e) => {
                       (e.target as HTMLImageElement).src = "https://raw.githubusercontent.com/tanvir8332/Portfolio-Images/main/Tanvir-Portrait-Clean.png";
                     }}
                     alt={BRAND_INFO.name} 
                     className="w-full rounded-[2.5rem] grayscale hover:grayscale-0 transition-all duration-700" 
                   />
                </div>
                <div className="p-10 bg-neutral-900 rounded-[3rem] border border-white/5">
                   <Quote className="text-red-500/20 mb-6" size={48} />
                   <p className="text-2xl font-brand font-bold text-white leading-tight">
                     "My mission is to help Bangladeshi founders build businesses that can run even when they are sleeping."
                   </p>
                </div>
             </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
