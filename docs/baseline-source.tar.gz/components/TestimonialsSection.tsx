
import React, { useState, useEffect } from 'react';
import { motion as _motion, AnimatePresence } from 'framer-motion';
import { Star, Quote, ChevronLeft, ChevronRight } from 'lucide-react';
import { REVIEWS } from '../constants';

const motion = _motion as any;

const TestimonialsSection: React.FC = () => {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % REVIEWS.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const next = () => setIndex((prev) => (prev + 1) % REVIEWS.length);
  const prev = () => setIndex((prev) => (prev - 1 + REVIEWS.length) % REVIEWS.length);

  return (
    <section id="testimonials" className="py-24 bg-neutral-950 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-brand font-black mb-4">What Founders Say</h2>
          <p className="text-neutral-500 max-w-2xl mx-auto text-lg">
            Real feedback from business owners who transformed their operations with my systems.
          </p>
        </motion.div>

        <div className="relative max-w-4xl mx-auto min-h-[400px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={REVIEWS[index].id}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="bg-neutral-900/50 backdrop-blur-md border border-white/5 rounded-[3rem] p-10 md:p-16 flex flex-col md:flex-row items-center gap-10 md:gap-16 shadow-2xl"
            >
              <div className="w-32 h-32 md:w-48 md:h-48 shrink-0 rounded-[2rem] overflow-hidden border-4 border-white/5 shadow-xl">
                <img src={REVIEWS[index].image} alt={REVIEWS[index].name} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 space-y-6 text-center md:text-left">
                <Quote className="text-red-500 w-12 h-12 mx-auto md:mx-0 opacity-20" />
                <p className="text-2xl md:text-3xl font-medium text-white leading-relaxed italic">
                  "{REVIEWS[index].quote}"
                </p>
                <div className="flex justify-center md:justify-start gap-1">
                  {[...Array(REVIEWS[index].rating)].map((_, i) => (
                    <Star key={i} className="text-yellow-500 fill-yellow-500" size={18} />
                  ))}
                </div>
                <div>
                  <h4 className="text-xl font-bold text-white">{REVIEWS[index].name}</h4>
                  <p className="text-red-500 font-semibold">{REVIEWS[index].role}</p>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation Controls */}
          <div className="absolute -bottom-12 left-1/2 -translate-x-1/2 flex items-center gap-4">
            <button 
              onClick={prev}
              className="p-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-white transition-all"
            >
              <ChevronLeft size={24} />
            </button>
            <div className="flex gap-2">
              {REVIEWS.map((_, i) => (
                <div 
                  key={i} 
                  className={`h-1.5 rounded-full transition-all ${index === i ? 'w-8 bg-red-500' : 'w-2 bg-white/20'}`}
                ></div>
              ))}
            </div>
            <button 
              onClick={next}
              className="p-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-white transition-all"
            >
              <ChevronRight size={24} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
